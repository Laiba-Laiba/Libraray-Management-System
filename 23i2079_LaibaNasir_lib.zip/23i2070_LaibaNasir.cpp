#include<iostream>

using namespace std;



//-------------------------BOOK CLASS--------------------------//



class Book

{

public:

    int BookID;

    string BookTitle;

    string BookAuthor;

    string BookGenre;

    double Book_YearOfPublication;                // all the data of book    

    int Book_NoOfCopies;

    string Book_Status;



    Book()

    {

        // default constructor

    }



    Book(int id, string BT, string BA, string BG, double By, int NoCop, string BS) {

        BookID = id;

        BookTitle = BT;

        BookAuthor = BA;

        BookGenre = BG;

        Book_YearOfPublication = By;   // parameterized constructor

        Book_NoOfCopies = NoCop;

        Book_Status = BS;

    }



    void displayBooks()

    {

        cout << "\n\n\t\t\t\033[35m *******************  DISPLAYING BOOKS **************\033[0m\n\n\n";

        cout << " Book ID                  : " << BookID << endl

            << " Book Title               : " << BookTitle << endl

            << " Book Author              : " << BookAuthor << endl

            << " Book Genre               : " << BookGenre << endl                    // displaying all the books

            << " Book Year Of Publication : " << Book_YearOfPublication << endl

            << " No Of Copies             : " << Book_NoOfCopies << endl

            << " Book Status              : " << Book_Status << endl << endl;



        cout << endl << endl;

    }

};



class BookNode

{

public:

    Book data;  // object of book class contain all the data of book  in booknode 

    BookNode* next;



    BookNode()

    {

        next = NULL;   // constructor of book node class initializing next pointer of book node = null

    }

};



class Patron

{

public:

    int PatronID;

    string Patronname;

    string PatronContactNo;

    string PatronEmail;

    string PatronAdress;

    string PatronLibCard_Status;





    Patron()

    {

        // default constructor

    }



    Patron(int id, string PN, string Pcontact, string PatronMAIL, string PA, string PS)

    {

        PatronID = id;

        Patronname = PN;

        PatronContactNo = Pcontact;

        PatronEmail = PatronMAIL;

        PatronAdress = PA;        // parameterized constructor

        PatronLibCard_Status = PS;



    }



    void displayPatrons()

    {

        cout << "\n\n\t\t\t\t\033[35m *******************  DISPLAYING PATRONS **************\033[0m\n\n\n";

        cout << " Patron ID                    : " << PatronID << endl

            << " Patron name                  : " << Patronname << endl

            << " Patron Contact number        : " << PatronContactNo << endl

            << " Patron Email                 : " << PatronEmail << endl                    // displaying all the books

            << " Patron Adress                : " << PatronAdress << endl

            << " Patron Card Status           : " << PatronLibCard_Status << endl;





        cout << endl << endl;

    }

};



class PatronNode

{

public:

    Patron data;  // object of user class contain all the data of user  in patronnode 

    PatronNode* next;



    PatronNode()

    {

        next = NULL;   // constructor of user node class initializing next pointer of patron node = null

    }

};



class Borrow

{

public:



    int Patronid;

    int Bookid;

    int dateofBorrowing;

    int monthOfBorrowing;

    int YearOfBorrowning;
    
    int dueDate;
    int dueMonth;
    int dueYear;







    Borrow() : Patronid(0), Bookid(0), dateofBorrowing(0), monthOfBorrowing(0), YearOfBorrowning(0), dueDate(0), dueMonth(0), dueYear(0)

    {}



    Borrow(int userid, int bookid, int DB, int MB, int YB ) : Patronid(userid), Bookid(bookid), dateofBorrowing(DB), monthOfBorrowing(MB), YearOfBorrowning(YB), dueDate(0), dueMonth(0), dueYear(0)

    { }



    bool isLeapYear(int year)

    {

        return (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0));

    }



    int daysInMonth(int month, int year)

    {

        switch (month)

        {

        case 2: // February

            return isLeapYear(year) ? 29 : 28;



        case 4: case 6: case 9: case 11: // April, June, September, November

            return 30;



        default: // January, March, May, July, August, October, December

            return 31;

        }

    }





    void calculateduedate(int day, int month, int year, int daysToAdd)

    {

        int duedate = day + daysToAdd; // Adding days

        int duemonth = month;

        int dueyear = year;



        // Adjust for overflow days in the current month

        while (duedate > daysInMonth(duemonth, dueyear))

        {

            duedate -= daysInMonth(duemonth, dueyear); // Reduce extra days

            duemonth++; // Move to the next month



            // If month exceeds December, increment the year

            if (duemonth > 12)

            {

                duemonth = 1;

                dueyear++;

            }

        }



        // Output the calculated due date

        cout << "\t\n\n\033[35m Due date for returning BOOK is : \033[0m" << duedate << "-" << duemonth << "-" << dueyear << endl;
        
        dueDate = duedate;
        dueMonth = duemonth ;
        dueYear = dueyear;

    }



    void DisplayBorrowRecord()

    {

        cout << " USER ID " << Patronid << endl

            << " BOOK ID " << Bookid << endl

            << "\033[35m DATE OF BORROWING : \033[0m" << dateofBorrowing << " - " << monthOfBorrowing << " - " << YearOfBorrowning << endl;
            cout << "\t\n\n\033[31m Due date for returning BOOK is \033[0m: " << dueDate << "-" << dueMonth << "-" << dueYear << endl;

    }





};



class BorrowNode

{

public:

    Borrow data;

    BorrowNode* next;



    BorrowNode()

    {

        next = NULL;

    }

};

class LinkedList

{

private:



    BookNode* BookHead;

    BookNode* BookTail;

    PatronNode* PatronHead;

    PatronNode* PatronTail;

    BorrowNode* BorrowHead;

    BorrowNode* BorrowTail;

public:



    LinkedList()

    {

        BookHead = NULL;

        BookTail = NULL;

        PatronHead = NULL;

        PatronTail = NULL;

        BorrowHead = NULL;

        BorrowTail = NULL;

    }

    //-------------------------MEMBER FUNCTIONS FOR BOOKS-------------------------//





    bool check_Unique_BOOKID(int id)

    {

        BookNode* temp = BookHead;

        while (temp != NULL)

        {

            if (temp->data.BookID == id)

            {

                return true;

            }

            temp = temp->next;  // Added missing traversal of temp

        }

        return false;

    }



    void AddBook(Book b)

    {



        BookNode* temp = new BookNode; // creating an empty node to add 

        temp->data = b;



        if (BookHead == NULL && BookTail == NULL)

        {

            BookHead = temp;

            BookTail = temp;

        }

        else

        {

            BookTail->next = temp;

            BookTail = temp;

        }

    }

    bool SearchBooks(string name)

    {

        if (IsEmpty())

        {

            cout << "\033[31m List Is Empty \033[0m\n";

        }



        else

        {

            BookNode* temp = BookHead;

            bool found = false;

            while (temp != NULL)

            {



                if (temp->data.BookTitle == name || temp->data.BookAuthor == name || temp->data.BookGenre == name || temp->data.Book_Status == name)

                {



                    cout << "\n\033[32m BOOK FOUND \033[0m\n\n";

                    found = true;



                    return true;

                }

                temp = temp->next;

            }



            if (!found && temp == NULL)

            {

                cout << "\n\n\033[31m THE Book You Are Trying TO find by \" " << name << " \" IS NOT AVAILABLE / NOT FOUND \033[0m\n\n";

                return false;

            }

        }

        return 0;

    }





    bool SearchBooks(int id)

    {

        if (IsEmpty())

        {

            cout << "\n\n\033[31m NO BOOK AVAILABLE IN LIBRARY \033[0m\n";

        }



        else

        {

            BookNode* temp = BookHead;

            bool found = false;

            while (temp != NULL)

            {



                if (temp->data.BookID == id)

                {

                    cout << "\n\033[32m BOOK FOUND \033[0m\n\n";

                    found = true;



                    return true;

                }



                temp = temp->next;

            }



            if (!found && temp == NULL)

            {

                cout << "\n\n\033[31m THE Book You Are Trying TO find by " << id << " IS NOT AVAILABLE / NOT FOUND \033[0m\n";

                return false;



            }



        }

        return 0;

    }





    void UpdateBooks(int id)

    {



        int op;

        BookNode* temp = BookHead;

        if (IsEmpty())

        {

            cout << "\n\033[31m LIBRARY IS EMPTY\033[0m\n";

        }



        while (temp != NULL && temp->data.BookID != id)

        {

            temp = temp->next;

        }



        if (temp == NULL)

        {

            cout << "\n\n\033[31m WRONG ID : BOOK IS NOT AVAILABLE \033[0m\n\n";


        }



        else if (temp->data.BookID == id)

        {

            cout << "\n\n\033[32m BOOK FOUND\033[0m\n";



            cout << "\n\t\t\033[35m  START UPDATING BOOK \033[0m\n";



            cout << "\nEnter New ID ::";

            cin >> temp->data.BookID;





            cout << "\nEnter New Title ::";

            cin >> temp->data.BookTitle;





            cout << "\nEnter New Author ::";

            cin >> temp->data.BookAuthor;





            cout << "\nEnter New Genre ::";

            cin >> temp->data.BookGenre;







            cout << "\nEnter New Year Of Publication ::";

            cin >> temp->data.Book_YearOfPublication;







            cout << "\nEnter Updated No.OF Copies ::";

            cin >> temp->data.Book_NoOfCopies;





            cout << "\n\n\t\t\t\033[35m ************ UPDATED BOOK IS ************ \033[0m\n\n";

            temp->data.displayBooks();



        }



    }
    
    void deleteBook(int bookID) 
    {
    // Check if the book is borrowed
    BorrowNode* borrowTemp = BorrowHead;
    while (borrowTemp != NULL) 
    {
        if (borrowTemp->data.Bookid == bookID) 
        {
            cout << "\n\n\t\t\033[31m Book with ID " << bookID << " cannot be deleted because it is currently borrowed.\033[0m\n";
            return; // Exit the function if the book is borrowed
        }
        borrowTemp = borrowTemp->next;
    }

    // If the book is not borrowed, proceed to delete it from the collection
    BookNode* bookTemp = BookHead;
    BookNode* prevBook = NULL;
    
    while (bookTemp != NULL && bookTemp->data.BookID != bookID) 
    {
    
        prevBook = bookTemp;
        bookTemp = bookTemp->next;
    }

    // If book is found, delete it
    if (bookTemp != NULL) 
    {
        if (prevBook != NULL) 
        {
            prevBook->next = bookTemp->next; // Skip the node to delete it
        } 
        else 
        {
            BookHead = bookTemp->next; // If deleting the first node
        }
        delete bookTemp; // Free the memory
        cout << "\n\n\033[31mBook with ID " << bookID << " has been successfully deleted.\033[0m\n";
    } 
    else 
    {
        cout << "\n\n\033[31mBook with ID " << bookID << " not found in the collection.\033[0m\n";
    }
}


    bool IsEmpty()

    {

        if (BookHead == NULL && BookTail == NULL)

        {

            cout << "\n\n\033[31m NO BOOK AVAILABLE IN LIBRARY(LIBRARY IS EMPTY) \033[0m\n";

            return true;

        }

        else

        {



            return false;

        }

    }





    void PrintBooks()

    {

        BookNode* temp = BookHead;



        while (temp != NULL)

        {

            temp->data.displayBooks();

            temp = temp->next;

        }

    }





    //-------------------------------USER MEMBER FUNCTIONS--------------------------- //



    bool check_Unique_USERID(int id)

    {

        PatronNode* temp = PatronHead;

        while (temp != NULL)

        {

            if (temp->data.PatronID == id)

            {

                return true;

            }

            temp = temp->next;  // Added missing traversal of temp

        }

        return false;

    }



    void AddPatrons(Patron P)

    {



        PatronNode* temp = new PatronNode; // creating an empty node to add 

        temp->data = P;



        if (PatronHead == NULL && PatronTail == NULL)

        {

            PatronHead = temp;

            PatronTail = temp;

        }

        else

        {

            PatronTail->next = temp;

            PatronTail = temp;

        }

    }



    void PrintPatrons()

    {

        PatronNode* temp = PatronHead;



        while (temp != NULL)

        {

            temp->data.displayPatrons();

            temp = temp->next;

        }

    }



    bool SearchPatrons(string name)

    {

        if (IsEmpty())

        {

            cout << "\n\t\033[31m List Is Empty \033[0m\n";

        }



        else

        {

            PatronNode* temp = PatronHead;

            bool found = false;

            while (temp != NULL)

            {



                if (temp->data.Patronname == name || temp->data.PatronEmail == name)

                {



                    cout << "\n\n\t\t\033[32m  USER FOUND \033[0m\n\n";

                    found = true;



                    return true;

                }

                temp = temp->next;

            }



            if (!found && temp == NULL)

            {

                cout << "\n\n\033[31m THE USER You Are Trying TO find by \" " << name << " \" IS NOT AVAILABLE / NOT FOUND \033[0m\n";

                return false;

            }

        }

        return 0;

    }



    bool SearchPatrons(int id)

    {

        if (IsEmpty())

        {

            cout << "\n\n\t\033[31m NO USER REGISTERED IN LIBRARY \033[0m\n";

        }



        else

        {

            PatronNode* temp = PatronHead;

            bool found = false;

            while (temp != NULL)

            {



                if (temp->data.PatronID == id)

                {

                    cout << "\n\033[32m  Patron FOUND \033[0m\n\n";

                    found = true;



                    return true;

                }



                temp = temp->next;

            }



            if (!found && temp == NULL)

            {

                cout << "\n\n\033[31m THE USER You Are Trying TO find by " << id << " IS NOT AVAILABLE / NOT FOUND \033[0m\n";

                return false;



            }



        }

        return 0;

    }



    void UpdatePatrons(int id)

    {



        int op;

        PatronNode* temp = PatronHead;

        if (IsEmpty())

        {

            cout << "\n\033[32m NO USER REGISTERED \033[0m\n";

        }



        while (temp != NULL && temp->data.PatronID != id)

        {

            temp = temp->next;

        }



        if (temp == NULL)

        {

            cout << "\n\n\033[31m WRONG ID : Patron IS NOT AVAILABLE \033[0m\n\n";

            return;

        }



        else if (temp->data.PatronID == id)

        {

            int op;

            cout << "\n\n\033[32m Patron FOUND \033[0m\n\n";



            cout << " WHAT YOU WANT TO UPDATE\n";

            do {

                cout << "1- ADRESS \n"

                    << "2- CONTACT NUMBER\n"

                    << "3- EMAIL ADRESS\n"

                    << "4- USER ID \n"

                    << "5- USER NAME\n"

                    << "6- EXIT\n";

                cout << " \n\nENTER OPTION: ";

                cin >> op;

                switch (op)

                {

                case 1:

                {

                    cout << "\nEnter New Adress ::";

                    cin >> temp->data.PatronAdress;



                    cout << "\n\n\t\033[32m ************ USER INFO IS UPDATED ************ \033[0m\n\n";

                    temp->data.displayPatrons();



                    break;

                }



                case 2:

                {

                    cout << "\nEnter New Contact Number  ::";

                    cin >> temp->data.PatronContactNo;

                    cout << "\033[32m ************ USER INFO IS UPDATED ************ \033[0m\n\n";

                    temp->data.displayPatrons();

                    break;

                }



                case 3:

                {

                    cout << "\nEnter New Email Adress ::";

                    cin >> temp->data.PatronEmail;

                    cout << "\n\033[32m ************ USER INFO IS UPDATED ************ \033[0m\n\n";

                    temp->data.displayPatrons();

                    break;

                }



                case 4:

                {



                    cout << "\n\n\t\033[31m IF YOU WANT TO UPDATE ID SO U HAVE TO UPDATE ALL INFO OF NEW USER (each uer has unique id)\033[0m\n\n";



                    cout << "\nEnter New ID  ::";

                    cin >> temp->data.PatronID;

                    cout << endl;



                    cout << "\nEnter New Name  ::";

                    cin >> temp->data.Patronname;

                    cout << endl;



                    cout << "\nEnter New Adress ::";

                    cin >> temp->data.PatronAdress;



                    cout << "\nEnter New Contact Number  ::";

                    cin >> temp->data.PatronContactNo;



                    cout << "\nEnter New Email Adress ::";

                    cin >> temp->data.PatronEmail;



                    cout << "\n\n\033[32m ************ USER INFO IS UPDATED ************ \033[0m\n\n";

                    temp->data.displayPatrons();

                    break;

                }



                case 5:

                {

                    cout << "\n\n\t\033[31m IF YOU WANT TO CHANGE NAME SO CHANGE ALL CREDENTIALS \033[0m\n\n";



                    cout << "\nEnter New Name  ::";

                    cin >> temp->data.Patronname;

                    cout << endl;



                    cout << "\nEnter New ID  ::";

                    cin >> temp->data.PatronID;

                    cout << endl;



                    cout << "\nEnter New Adress ::";

                    cin >> temp->data.PatronAdress;



                    cout << "\nEnter New Contact Number  ::";

                    cin >> temp->data.PatronContactNo;



                    cout << "\nEnter New Email Adress ::";

                    cin >> temp->data.PatronEmail;



                    cout << "\n\n\033[32m ************ USER INFO IS UPDATED ************ \033[0m\n\n";

                    temp->data.displayPatrons();



                    break;

                }

                case 6:

                    cout << " \nEXITING \n";

                default:

                    cout << "\n\n\t\t\033[31m INVALID CHOICE \033[0m\n\n";



                }

            } while (op != 6);

        }

    }
    
    void handleDeletePatron() 
    {
    int patronID;
    cout << "Enter the ID of the patron you want to delete: ";
    cin >> patronID;

    if (hasReturnedAllBooks(patronID)) 
    {
        deletePatron(patronID);
    } 
    else
     {
        cout << "\n\t\t\033[31m Patron with ID " << patronID << " has not returned all borrowed books. Cannot delete.\033[0m\n";
    }
}

bool hasReturnedAllBooks(int patronID) 
{
    BorrowNode* borrowTemp = BorrowHead;

    while (borrowTemp != NULL) 
    {
        if (borrowTemp->data.Patronid == patronID) 
        {
            
            return false;
        }
        borrowTemp = borrowTemp->next;
    }

   
    return true;
}

// Function to delete a patron
void deletePatron(int patronID) 
{
    PatronNode* patronTemp = PatronHead;
    PatronNode* prevPatron = NULL;
    
    while (patronTemp != NULL && patronTemp->data.PatronID != patronID) 
    {
        prevPatron = patronTemp;
        patronTemp = patronTemp->next;
    }

    if (patronTemp != NULL) 
    {
        if (prevPatron != NULL) 
        {
            prevPatron->next = patronTemp->next;
        } 
        else 
        {
            PatronHead = patronTemp->next;
        }
        delete patronTemp;
        cout << "\n\n\t\033[32m Patron with ID " << patronID << " has been successfully deleted.\033[0m\n";
    } 
    else 
    {
        cout << "\n\t\t\033[31m Patron with ID " << patronID << " not found in the system.\033[0m\n";
    }
}

    //----------------------BORROW MEMBER FUNCTIONS ----------------------//



    void AddBorrowRecords(Borrow B)

    {



        BorrowNode* temp = new BorrowNode; // creating an empty node to add 

        temp->data = B;



        if (BorrowHead == NULL && BorrowTail == NULL)

        {

            BorrowHead = temp;

            BorrowTail = temp;

        }

        else

        {

            BorrowTail->next = temp;

            BorrowTail = temp;

        }

    }



    void PrintBorrowRecs()

    {

        BorrowNode* temp = BorrowHead;



        while (temp != NULL)

        {

            temp->data.DisplayBorrowRecord();

            temp = temp->next;

        }

    }
    
    bool LimitReached(int PatronID)
{
    BorrowNode* temp = BorrowHead;  
    int count = 0;

    while(temp != NULL)
    {
        if(temp->data.Patronid == PatronID)
        {
            count++;
        }
        temp = temp->next;
    }

    // If the patron has already borrowed 3 books
    if(count >= 3)
    {
        cout << "\n\n\n\033[31m You have already borrowed 3 books. Please return one before borrowing more.\033[0m\n\n\n";
        return true;  // Limit reached
    }

    return false;  // Limit not reached
}

 void reduceNoOfCopies(int id)
 {
  BookNode * temp = BookHead;
 
  
  while(temp!= NULL &&  temp->data.BookID != id)
  {
    temp = temp->next;
  }
  
 
  if( temp == NULL)
  {
     cout<<"\n\t\t\033[31m  No id available\033[0m\n";
     return;
  }
  
  if(temp->data.Book_NoOfCopies > 0)
    {
        temp->data.Book_NoOfCopies--;
        cout << "\n\n\033[35m Number of copies for Book ID " << id << " reduced by 1. Remaining copies: \033[0m" << temp->data.Book_NoOfCopies << "\n\n\n";
       
    }
    else
    {
        cout << "\n\n\033[31m No copies left for Book ID \033[0m" << id << "\n\n\n";
    }
    
    
}

void updateBookStatus(int id)
{
    BookNode* temp = BookHead;  
    
    
    while(temp != NULL && temp->data.BookID != id)
    {
        temp = temp->next;
    }

    
    if(temp == NULL)
    {
        cout << "\n\033[31m No book with the given ID available\033[0m\n";
        return;
    }

    // If the book is found and there are no copies left, mark it as borrowed
    if(temp->data.Book_NoOfCopies == 0)
    {
        temp->data.Book_Status = "borrowed";
        cout << "\n\033[35m All copies of Book ID " << id << " are borrowed. The book is unavailable at this time.\033[0m\n";
    }
    else
    {
        temp->data.Book_Status = "available";
    }
}

string getBookStatus(int id)
{
    BookNode* temp = BookHead;

    while(temp != NULL && temp->data.BookID != id)
    {
        temp = temp->next;
    }

    if(temp == NULL)
    {
        return "not found";  // In case no book with the ID exists
    }

    return temp->data.Book_Status;  // Return the status of the book
}

void returnBook(int PatronID, int BookID, int returnDate, int returnMonth, int returnYear)
{
    BorrowNode* temp =BorrowHead;  
    BorrowNode* prev = NULL;
    bool bookFound = false;

    
    while(temp != NULL)
    {
        if(temp->data.Patronid == PatronID && temp->data.Bookid == BookID)
        {
            bookFound = true;

            // Calculate if the book is returned after the due date
            if(isLate(temp->data.dueDate, temp->data.dueMonth, temp->data.dueYear, returnDate, returnMonth, returnYear))
            {
                cout << "\n\033[31m Book returned late! A fine of ₹1000 has been applied.\033[0m\n";
            }
            else
            {
                cout << "\n\n\033[32m Book returned on time. No fine.\033[0m\n";
            }

            // Update the book's availability (increase number of copies)
            increaseNoOfCopies(BookID);

            // Remove the borrow record from the list
            if(prev == NULL) // If the book to return is the first in the list
            {
                BorrowHead = temp->next;
            }
            else
            {
                prev->next = temp->next;
            }

            delete temp;  // Free the memory of the returned book's borrow record
            cout << "\n\033[35;1m Book returned successfully.\033[0m\n";
            return;
        }

        prev = temp;
        temp = temp->next;
    }

    if(!bookFound)
    {
        cout << "\n\033[31m No borrow record found for the given Patron and Book.\033[0m\n";
    }
}

bool isLate(int dueDate, int dueMonth, int dueYear, int returnDate, int returnMonth, int returnYear)
{
    
     if (returnYear > dueYear)
    {
        return true;
    }
    
    else if (returnYear < dueYear)
    {
        return false;
    }

   
    if (returnMonth > dueMonth)
    {
        return true;  // Late if return month is after due month
    }
    else if (returnMonth < dueMonth)
    {
        return false;  // On time if return month is before due month
    }

    
    if (returnDate > dueDate)
    {
        return true;  // Late if return day is after due day
    }

    return false;  // On time if return day is before or equal to the due day
}

void increaseNoOfCopies(int id)
{
    BookNode* temp = BookHead;

    while(temp != NULL && temp->data.BookID != id)
    {
        temp = temp->next;
    }

    if(temp == NULL)
    {
        cout << "\n\033[31m No book with the given ID available\033[0m\n";
        return;
    }

    // Increase the number of copies
    temp->data.Book_NoOfCopies++;
    cout << "\n\033[35m Number of copies for Book ID " << id << " increased. Total copies: \033[0m" << temp->data.Book_NoOfCopies << "\n";

    // Update the book status to available if there are copies
    if(temp->data.Book_NoOfCopies > 0)
    {
        temp->data.Book_Status = "available";
    }
}


 bool isOverdue(BorrowNode* node, int currentDay, int currentMonth, int currentYear) {
        if (node->data.dueYear < currentYear)
            return true;
        else if (node->data.dueYear == currentYear && node->data.dueMonth < currentMonth)
            return true;
        else if (node->data.dueYear == currentYear && node->data.dueMonth == currentMonth && node->data.dueDate < currentDay)
            return true;

        return false;
    }
    
    
void displayOverdueBooks(int currentDay, int currentMonth, int currentYear) 
{
    BorrowNode* temp1 = BorrowHead;
    bool overdueFound = false;

    cout << "\n\033[36m Checking for overdue books...\033[0m\n";

    while (temp1 != NULL) 
    {
        // Check if the current borrow record is overdue
        if (isOverdue(temp1, currentDay, currentMonth, currentYear)) 
        {
            overdueFound = true;
            cout << "\n\t\t\033[35m Overdue Book Details:\033[0m\n";

            // Find the patron node with the matching Patronid
            PatronNode* temp2 = PatronHead;
            while (temp2 != NULL) 
            {
                if (temp2->data.PatronID == temp1->data.Patronid) 
                {
                    // Display patron details
                    temp2->data.displayPatrons();
                    break;
                }
                temp2 = temp2->next;
            }

            // Display book details
            cout << "Book ID: " << temp1->data.Bookid << "\n";
            cout << "Borrow Date: " << temp1->data.dateofBorrowing
                 << "-" << temp1->data.monthOfBorrowing
                 << "-" << temp1->data.YearOfBorrowning << "\n";
            cout << "Due Date: " << temp1->data.dueDate
                 << "-" << temp1->data.dueMonth
                 << "-" << temp1->data.dueYear << "\n";
        }
        temp1 = temp1->next;
    }

    if (!overdueFound) 
    {
        cout << "\033[35m No overdue books found.\033[0m\n";
    }
}

void displayBooksCurrentlyBorrowed()
{
    BorrowNode* temp = BorrowHead;
    cout << "\n\033[35m Books Currently Borrowed:\033[0m\n";
    
    if (temp == NULL)
    {
        cout << "\033[32m No books are currently borrowed.\033[0m\n";
        return;
    }
    
    while (temp != NULL)
    {
        cout << "\nBook ID: " << temp->data.Bookid << "\n";
        cout << "Borrow Date: " << temp->data.dateofBorrowing << "-" 
             << temp->data.monthOfBorrowing << "-" 
             << temp->data.YearOfBorrowning << "\n";
        cout << "Due Date: " << temp->data.dueDate << "-" 
             << temp->data.dueMonth << "-" 
             << temp->data.dueYear << "\n";
        
        PatronNode* patronTemp = PatronHead;
        while (patronTemp != NULL)
        {
            if (patronTemp->data.PatronID == temp->data.Patronid)
            {
                cout << "Borrower ID: " << patronTemp->data.PatronID << "\n";
                patronTemp->data.displayPatrons();
                break;
            }
            patronTemp = patronTemp->next;
        }
        temp = temp->next;
    }
}

void displayBooksAvailable()
{
    BookNode* temp = BookHead;
    cout << "\t\t\n\033[35m Books Available in the Library:\033[0m\n";
    
    if (temp == NULL)
    {
        cout << "\n\t\t\t\033[31m No books are available in the library.\033[0m\n";
        return;
    }
    
    while (temp != NULL)
    {
        if (temp->data.Book_NoOfCopies > 0)
        {
            cout << "\nBook ID: " << temp->data.BookID << "\n";
            cout << "Title: " << temp->data.BookTitle << "\n";
            cout << "Author: " << temp->data.BookAuthor << "\n";
            cout << "Available Copies: " << temp->data.Book_NoOfCopies << "\n";
        }
        temp = temp->next;
    }
}
void displayAllPatronsBorrowingHistory() 
{
    PatronNode* patronTemp = PatronHead; // Head of the patron list

    while (patronTemp != NULL) 
    {
        cout << "\n\t\t\033[35m Borrowing History for Patron ID \033[0m" << patronTemp->data.PatronID << ":\n";
        BorrowNode* borrowTemp = BorrowHead; // Head of the borrow list
        bool historyFound = false;
        
        while (borrowTemp != NULL) 
        {
            if (borrowTemp->data.Patronid == patronTemp->data.PatronID) 
            {
                historyFound = true;
                
                // Display book details
                BookNode* bookTemp = BookHead; // Head of the book list
                while (bookTemp != NULL) 
                {
                    if (bookTemp->data.BookID == borrowTemp->data.Bookid) 
                    {
                        cout << "\n\033[35m Book Details:\033[0m\n";
                        cout << "Book ID: " << bookTemp->data.BookID << "\n";
                        cout << "Title: " << bookTemp->data.BookTitle << "\n";
                        cout << "Author: " << bookTemp->data.BookAuthor << "\n";
                        cout << "Available Copies: " << bookTemp->data.Book_NoOfCopies << "\n";
                        break; // Exit the book loop once the book is found
                    }
                    bookTemp = bookTemp->next;
                }

                // Display borrow details
                cout << "\nBorrow Date: " << borrowTemp->data.dateofBorrowing << "-" 
                     << borrowTemp->data.monthOfBorrowing << "-" 
                     << borrowTemp->data.YearOfBorrowning << "\n";
                cout << "Due Date: " << borrowTemp->data.dueDate << "-" 
                     << borrowTemp->data.dueMonth << "-" 
                     << borrowTemp->data.dueYear << "\n";
            }
            borrowTemp = borrowTemp->next;
        }
        
        if (!historyFound) 
        {
            cout << "\t\t\n\033[31m No borrowing history found.\033[0m\n";
        }

        patronTemp = patronTemp->next;
    }
}

};



int main()

{


    cout << "\n\n\t\t\t\t\t\t\033[35m*************************************************************************************\033[0m\n"

        << "            \t\t\t\t\t\033[35m**                                                                                 **\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                            ---DATA STRUCTURES---                            \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                              ASSIGNMENT NO . 1                              \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                                 LAIBA NASIR                                 \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                              ROLL NO . 23I-2079                             \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                                    CYS-A                                    \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                          LIBRARY MANAGEMENT SYSTEM                          \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m**                                                                                 **\033[0m\n"

        << "            \t\t\t\t\t\033[35m*************************************************************************************\033[0m\n";





    Book b1(12, "novel", "john", "fictional", 2008, 3, "available");

    Book b2(13, "story book", "elsa", "fantasy", 2009, 4, "available");

    Book b3(14, "Maths", "einstien", "algebra", 2010, 5, "available");

    Book b4(15, "physics", "newton", "quantum", 2011, 6, "available");

    Book b5(16, "computer", "babbage", "data structures", 2012, 7, "available");



    Patron p1(1, "john", "0312-1234567", "john@gmail.com", "london,street:12", "active");

    Patron p2(2, "aina", "0312-234567", "aina@gmail.com", "newyork,street:12", "active");

    Patron p3(3, "jenny", "0312-234567", "jenny@gmail.com", "canada,street:12", "active");

    Patron p4(4, "joseph", "0312-234567", "joseph@gmail.com", "japan,street:12", "active");



   




    LinkedList l1;  // Create the LinkedList 

    l1.AddBook(b1);

    l1.AddBook(b2);
                           // add books
    l1.AddBook(b3);

    l1.AddBook(b4);

    l1.AddBook(b5);



    l1.AddPatrons(p1);
                              // add patrons
    l1.AddPatrons(p2);

    l1.AddPatrons(p3);

    l1.AddPatrons(p4);



    


    int option;





    do 
{
    cout << "\n\n\t\t\t\t\t\t\t\033[35;3m    **************** MENU FOR LIBRARY ACCESS  ****************** \033[0m\n\n";
    cout << " 1-Access As A Staff Member \n";
    cout << " 2-Access As A Patron(User) \n";
    cout << " 3-EXIT\n\n";
    cout << "\n Enter your choice : ";
    cin >> option;

    int CHOICE;
    switch (option)
    {
        case 1:
        {
            do 
            {
                cout << "\nWould you like to manage books or handle patron accounts? \n\n";
                cout << " 1- BOOKS  \n";
                cout << " 2- USERS / PATRONS \n";
                cout << " 3- Track Over Due Books \n";
                cout << " 4- Generate REport \n";
                cout << " 5- EXIT\n\n";
                cout << " ENTER YOUR CHOICE ::"; 
                cin >> CHOICE;

                switch (CHOICE) 
                {
                    case 1: 
                    {
                        int choice;
                        do 
                        {
                            cout << "\n\n\n\n\t\t\t\t\t\t\t\033[32;3m   ************ Menu For Staff To Manage BOOKS *************** \033[0m\n\n"
                                 << " 1- Add New Book \n"
                                 << " 2- Search For Book \n"
                                 << " 3- Delete Book \n"
                                 << " 4- Update Book Info \n"
                                 << " 5- Display All Books in Library\n"
                                 << " 6- EXIT\n\n";
                            cout << "\nENTER YOUR CHOICE ::";
                            cin >> choice;

                            switch (choice) 
                            {
                                case 1:
                                {
                                    int id;
                                    string name, author, genre, status;
                                    double year_of_pub;
                                    int no_of_copies;

                                    cout << "\n\n\n\n\t\t\t\t\t\t\t\033[31;3m                ---- Enter Book Details ----- \033[0m\n\n";
                                    cout << " Enter book ID : ";
                                    cin >> id;
                                     cout<<endl;
                                    while (l1.check_Unique_BOOKID(id)) 
                                    {
                                        cout << "\n\033[31m Book ID is UNIQUE, book with " << id << " ID already exists. Please enter a new ID.\033[0m" << endl << endl;
                                        cout << " REenter Unique Book ID : ";
                                        cin >> id;
                                    }

                                    cout << " Enter book Name : ";
                                    cin >> name;
                                    cout<<endl;
                                    cout << " Enter book Author : ";
                                    cin >> author;
                                    cout<<endl;
                                    cout << " Enter book Genre : ";
                                    cin >> genre;
                                    cout<<endl;
                                    
                                    cout << " Enter book Year Of Publication : ";
                                    cin >> year_of_pub;
                                    cout<<endl;
                                    cout << " Enter No Of Copies  : ";
                                    cin >> no_of_copies;
                                    cout<<endl;
                                    cout << " Enter book Status(Available/ Borrowed) : ";
                                    cin >> status;
                                     cout<<endl;
                                    Book b1(id, name, author, genre, year_of_pub, no_of_copies, status);
                                    l1.AddBook(b1);
                                    cout << " \n\n\n\n\n\n\t\t\t\t\t\t\t\033[35;3m*************BOOK ADDED SUCCESSFULLY*************** \033[0m\n\n";
                                    l1.PrintBooks();  // Print all books
                                    break;
                                }
                                case 2:
                                {
                                    int option;
                                    string search;
                                    do 
                                    {
                                        cout << "\n\n\t\tMenu For Search \t\t\n\n";
                                        cout << " 1- Search By Title \n"
                                             << " 2- Search By Author \n"
                                             << " 3- Search By Genre \n"
                                             << " 4- Search By BookID \n"
                                             << " 5- Exit \n\n";
                                        cout << "\nENTER YOUR OPTION :: ";
                                        cin >> option;

                                        switch (option) 
                                        {
                                            case 1: 
                                            {
                                                cout << "\n\nEnter the Title of Book you Want to search :: ";
                                                cin >> search;
                                                l1.SearchBooks(search);
                                                break;
                                            }
                                            case 2: 
                                            {
                                                cout << "\nEnter the Author Name of Book you Want to search :: ";
                                                cin >> search;
                                                l1.SearchBooks(search);
                                                break;
                                            }
                                            case 3: 
                                            {
                                                cout << "\nEnter the Genre of Book you Want to search :: ";
                                                cin >> search;
                                                l1.SearchBooks(search);
                                                break;
                                            }
                                            case 4: 
                                            {
                                                int ID;
                                                cout << "\nEnter the ID of Book you Want to search :: ";
                                                cin >> ID;
                                                l1.SearchBooks(ID);
                                                break;
                                            }
                                           
                                            case 5: 
                                            {
                                                cout << "\n\nEXIT\n\n";
                                                break;
                                            }
                                            default:
                                                cout << "\n\nINVALID CHOICE \n\n";
                                        }
                                    } while (option != 5); // Ending of do-while loop for search book
                                    break;
                                }
                                case 3:
                                {
                                int id;
                                     cout<<"\n Enter the id of book you want to delete :: ";
                                     cin>>id;
                                     
                                     l1.deleteBook(id); 
                                break;
                                }
                                case 4:
                                {
                                    int id;
                                    cout << "\nENTER THE ID OF BOOK YOU WANT TO UPDATE : ";
                                    cin >> id;
                                    if (l1.IsEmpty()) 
                                    {
                                        cout << "\n\nLibrary is Empty \n";
                                    }
                                    l1.UpdateBooks(id);
                                    break;
                                }
                                case 5:
                                {
                                    l1.PrintBooks();
                                    break;
                                }
                                case 6:
                                    cout << "\n\033[36m Exiting...\033[0m" << endl;
                                    break;
                                default:
                                    cout << "\n\t\033[31m Invalid choice. Please enter a valid option from the menu.\033[0m\n\n";
                            }
                        } while (choice != 6);
                        break; // end of book operations
                    }
                    case 2:
                    {
                        int searchoption;
                        do 
                        {
                            cout << " \n\n\n\n\n\t\t\t\t\t\t\t\033[32;3m       ************ MENU FOR STAFF TO MANAGE USERS ***********\033[0m\n\n"
                                 << " 1- Register new USER \n"
                                 << " 2- Search User \n"
                                 << " 3- Delete User Record \n"
                                 << " 4- Update User Info \n"
                                 << " 5- Display All Users in Library\n"
                                 << " 6- EXIT\n\n";
                            cout << "\nEnter Your Choice to perform operation ::";
                            cin >> searchoption;

                            switch (searchoption) 
                            {
                                case 1:
                                {
                                    int id;
                                    string name, phone, mail, address, status;

                                    cout << "\n\t\t\n\n\n\n\t\t\t\t\t\t\t\033[31;3m                ----- Enter USER Details ----- \033[0m\n\n";
                                    cout << " Enter user ID : ";
                                    cin >> id;

                                    while (l1.check_Unique_USERID(id)) 
                                    {
                                        cout << "\n\n\033[31m Patron ID should UNIQUE, User with " << id << " ID already exists. Please enter a new ID.\033[0m" << endl << endl;
                                        cout << " REenter Unique User ID : ";
                                        cin >> id;
                                    }

                                    cout << " Enter USER Name : ";
                                    cin >> name;
                                    cout << " Enter Phone Number of user : ";
                                    cin >> phone;
                                    cout << " Enter Email of User : ";
                                    cin >> mail;
                                    cout << " Enter Address of user: ";
                                    cin >> address;
                                    cout << " Enter Library Card Status of user  : ";
                                    cin >> status;

                                    Patron p(id, name, phone, mail, address, status);
                                    l1.AddPatrons(p);
                                    cout << " \n\n\n\n\n\n\n\n\t\t\t\t\t\t\t\033[35;3m*************PATRON REGISTERED SUCCESSFULLY*************** \033[0m\n\n";
                                    l1.PrintPatrons();  // Print all patrons
                                    break;
                                }
                                case 2:
                                {
                                    int option;
                                    string search;
                                    int ID;
                                    do 
                                    {
                                        cout << "\n\n\t\tMenu For Search \n\n";
                                        cout << " 1- Search By ID \n"
                                             << " 2- Search By NAME \n"
                                             << " 3- Search By EMAIL \n"
                                             << " 4- Exit \n\n";
                                        cout << "\nENTER YOUR OPTION :: ";
                                        cin >> option;

                                        switch (option) 
                                        {
                                            case 1:
                                            {
                                                cout << "\n\nEnter the ID of USER you Want to search :: ";
                                                cin >> ID;
                                                l1.SearchPatrons(ID);
                                                break;
                                            }
                                            case 2:
                                            {
                                                cout << "\nEnter the USER Name of USER you Want to search :: ";
                                                cin >> search;
                                                l1.SearchPatrons(search);
                                                break;
                                            }
                                            case 3:
                                            {
                                                cout << "\nEnter the EMAIL of USER you Want to search :: ";
                                                cin >> search;
                                                l1.SearchPatrons(search);
                                                break;
                                            }
                                            case 4:
                                            {
                                                cout << "\n\033[36m ----Exit\033[0m\n";
                                                break;
                                            }
                                            default:
                                                cout << "\n\n\033[31m INVALID CHOICE \033[0m\n\n";
                                        }
                                    } while (option != 4); // ending of do-while loop for search user
                                    break;
                                }
                                case 3:
                                {
                                   l1.handleDeletePatron(); 
                                break;
                                }
                                case 4:
                                {
                                    int id;
                                    cout << "\nENTER THE ID OF USER YOU WANT TO UPDATE : ";
                                    cin >> id;
                                    if (l1.IsEmpty()) 
                                    {
                                        cout << "\n\n\033[31m NO USER REGISTERED\033[0m\n";
                                    }
                                    l1.UpdatePatrons(id);
                                    break;
                                }
                                case 5:
                                {
                                    l1.PrintPatrons();
                                    break;
                                }
                                case 6:
                                    cout << "\n\033[35m Exiting...\033[0m" << endl;
                                    break;
                                default:
                                    cout << "\n\n\t\033[31m Invalid choice. Please enter a valid option from the menu.\033[0m\n\n";
                            }
                        } while (searchoption != 6); // end of user management
                        break;
                    }
                    
                    case 3:
                    {
                       int currentDay, currentMonth, currentYear;
                        cout << "\nEnter the current date (DD MM YYYY) to check overdue books: ";
                         cin >> currentDay >> currentMonth >> currentYear;

                        // Check and display all overdue books
                      l1.displayOverdueBooks(currentDay, currentMonth, currentYear);

                       break;
                    }
                    
                    case 4:
                    {
                        int currentDay, currentMonth, currentYear;
                        cout<<"\t\n\t\t\t\033[36m  1- CURRENTLY BORROWED BOOKS \033[0m\n\n";
                        l1.displayBooksCurrentlyBorrowed();
                        cout<<endl<<endl;
                        
                        cout<< "\t\n\t\t\t\033[36m  2- BOOKS AVAILABLE IN LIBRARY \033[0m\n\n";
                        l1.displayBooksAvailable();
                        cout<<endl;
                        
                        cout << "\nEnter the current date (DD MM YYYY) to check overdue books: ";
                         cin >> currentDay >> currentMonth >> currentYear;
                           cout<<"\t\n\t\t\t\033[36m  3- LIST OF OVERDUE BOOKS AND THE BORROWERS \033[0m\n\n";
                        // Check and display all overdue books
                      l1.displayOverdueBooks(currentDay, currentMonth, currentYear);
                       
                        cout<<endl<<endl;
                        
                        cout<<"\t\n\t\t\t\033[36m  4- BORROWING HISTORY OF INDIVIDUAL PATRON \033[0m\n\n";
                        l1.displayAllPatronsBorrowingHistory() ;
                        
                     break;
                    }
                    case 5:
                    {
                        cout << "\n\t\t\033[35m Exiting... to main menu\033[0m\n";
                        break;
                    }
                    default:
                        cout << "\n\t\033[31m Invalid Choice. Please try again.\033[0m";
                }
            } while (CHOICE != 5);  // end of main staff menu
            break;
        }
       
            case 2: 
{
    int op;
    char select;
    int Pid;
    int Bid;
    int Bdate;
    int Bmonth;
    int Byear;
    int daysToAdd=14;
    int option;
    char name;
    int returnDate;
    int returnMonth ;
    int returnYear;
do
{
    cout << " 1- Borrow Book \n";
    cout << " 2- Return Book \n";
    cout << " 3- Exit \n\n";

    cout << "\nENTER CHOICE :: ";
    cin >> op;

    switch (op)
    {
    case 1:
    {
        cout << "\nEnter Your Id :: ";
        cin >> Pid;

        if (l1.SearchPatrons(Pid))
        {      
        // Check if the user has reached the borrowing limit
           if (l1.LimitReached(Pid))
              {
                   cout<<"\n\n\t\t\033[31m LIMIT REACHED \033[0m\n";
                   break;  // Exit if limit reached
                }
               cout<<"\n\t\t\033[35m  DISPLAYING ALL BOOKS IN LIBRARY \033[0m\n";
               l1.PrintBooks();
               cout<<" \nSelect Any BOOK which you want to BOrrow \n";
               
                cout << "\nEnter the id of book you want to borrow : ";             
                cin >> Bid;

                    if (l1.SearchBooks(Bid))
                    {
                    
                    if(l1.getBookStatus(Bid) == "borrowed")
            {
                cout << "\n\033[31m Sorry, all copies of this book are currently borrowed. Please visit another time.\033[0m\n";
                break;
            }
                        cout << "\nEnter Borrowing DATE : ";
                        cin >> Bdate;
                        cout << "\nEnter Borrowing Month : ";
                        cin >> Bmonth;
                        cout << "\nEnter Borrowing Year : ";
                        cin >> Byear;
                        
                        
                        Borrow B4(Pid, Bid, Bdate, Bmonth, Byear);
                        B4.calculateduedate(Bdate , Bmonth , Byear , daysToAdd);
                        l1.AddBorrowRecords(B4);
                        
                        l1.reduceNoOfCopies(Bid);

                    // Update the book status if needed
                       l1.updateBookStatus(Bid);
                        
                        
                       
                        
                    }
                    else
                    {
                        cout << "\n\t\t\033[31m NO BOOK AVAILABLE \033[0m\n\n";
                    }
                
                
                
                   
               }
               
               else
               { 
                  cout << "\t\n\t\t\033[31m NO ID AVAILABLE (NEW USER) \033[0m\n\n";
                  cout << " DO YOU WANT TO REGISTER IN LIBRARY To Access Books :: y/n : ";

                    cin >> select;



                    if (select == 'y' || select == 'Y')

                    {

                        int id;

                        string name;

                        string phone;

                        string mail;

                        string adress;

                        string status;



                        cout << "\n\t\t\t\t\t\t\t\t\033[32m            ----- Enter USER Details ----- \033[0m\n\n";

                        cout << " Enter user ID : ";

                        cin >> id;

                        while (l1.check_Unique_USERID(id))

                        {

                            cout << "\n\n\t\t\t\033[31m Patron ID should UNIQUE , User with   " << id << " ID already exists. Please enter a new ID.\033[0m" << endl << endl;

                            cout << " REenter Unique User ID : ";

                            cin >> id;

                        }



                        cout << endl;



                        cout << " Enter USER Name : ";

                        cin >> name;

                        cout << endl;



                        cout << " Enter Phone Number of user : ";

                        cin >> phone;

                        cout << endl;



                        cout << " Enter Email of User : ";

                        cin >> mail;

                        cout << endl;



                        cout << " Enter Adress of user: ";

                        cin >> adress;

                        cout << endl;



                        cout << " Enter Library Card Status of user  : ";

                        cin >> status;

                        cout << endl;







                        Patron p(id, name, phone, mail, adress, status);

                        l1.AddPatrons(p);

                        cout << " \n\n\n\t\t\t\t\t\033[32m *************PATRON REGISTERED SUCCESSFULLY*************** \033[0m\n\n";
                        
                        cout<<"\n\t\t\033[35m  DISPLAYING ALL BOOKS IN LIBRARY \033[0m\n\n";
                       l1.PrintBooks();
               cout<<" \t\nSelect Any BOOK which you want to BOrrow \n\n";
                cout << "\nEnter the id of book you want to borrow : ";             
               cin >> Bid;

                    if (l1.SearchBooks(Bid))
                    {
                       if(l1.getBookStatus(Bid) == "borrowed")
            {
                cout << "\n\t\t\t\033[31m Sorry, all copies of this book are currently borrowed. Please visit another time.\033[0m\n";
                break;
            }
                        cout << "\nEnter Borrowing DATE : ";
                        cin >> Bdate;
                        cout << "\nEnter Borrowing Month : ";
                        cin >> Bmonth;
                        cout << "\nEnter Borrowing Year : ";
                        cin >> Byear;

                        Borrow B5(Pid, Bid, Bdate, Bmonth, Byear);
                        B5.calculateduedate( Bdate , Bmonth , Byear , daysToAdd);
                        l1.AddBorrowRecords(B5);
                        
                        l1.reduceNoOfCopies(Bid);

                    // Update the book status if needed
                       l1.updateBookStatus(Bid);
                    }
                    else
                    {
                        cout << "\n\n\t\t\t\033[31m NO BOOK AVAILABLE \033[0m\n\n";
                    }
                

               }
            }
            break;
          } 
 
    case 2:
    {
        // Logic for returning books can be implemented here
         cout << "\nEnter Your Patron ID: ";
    cin >> Pid;

    cout << "\nEnter the Book ID to return: ";
    cin >> Bid;

    cout << "\nEnter the Return Date (day, month, year): ";
    cin >> returnDate >> returnMonth >> returnYear;

    // Call the returnBook function to process the return
    l1.returnBook(Pid, Bid, returnDate, returnMonth, returnYear);
   
        break;
    }
   case 3:
   cout<<" \n\t\t\033[35m EXITING \033[0m\n";
   break;
    default:
        cout << "\n\t\t\033[31m Invalid option selected.\033[0m";
        break;
    }
}while(op!=3);
        break;
} // end of user functions
           
        case 3:
            cout << "\n\n\t\t\t\t\t\t\t\t\t\033[41;3m Thanks for Accessing (EXITING ...)\033[0m\n\n";
            break;
        default:
            cout << "\n\t\t\033[31m  Invalid option. Try again! \033[0m\n";
    }
} while (option != 3); // end of main do-while loop

return 0;
}

